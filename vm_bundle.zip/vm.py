from typing import List, Dict, Optional

from .vm_insns import *


class Execution:
    def __init__(
        self,
        insns: List[Insn],
        memory: List[int],
        regs: Dict[str, int],
    ):
        self.insns: List[Insn] = insns
        self.memory: List[int] = memory
        self.regs: Dict[str, int] = regs
        if "FP" not in self.regs:
            self.regs["FP"] = 0
        if "SP" not in self.regs:
            self.regs["SP"] = 0
        if "PC" not in self.regs:
            self.regs["PC"] = 0
        self.labels: dict[str, int] = {}
        for i, insn in enumerate(self.insns):
            if isinstance(insn, Label):
                label = insn.label
                assert label not in self.labels, f"Duplicate label: {label}"
                self.labels[label] = i

        for insn in self.insns:
            if hasattr(insn, "label"):
                lab = getattr(insn, "label")
                assert lab in self.labels, f"Undefined label: {lab}"

        self.verbose = False

    def __repr__(self):
        return f"Execution({self.insns}, {self.regs})"

    def dump_state(self):
        insn = self.insns[self.regs["PC"]]
        frame = []
        if self.regs["FP"] == 0:
            caller = "N/A"
            frame = self.memory[self.regs["FP"] : self.regs["SP"]]
            frame = frame[:20]
        else:
            start = self.memory[self.regs["FP"] + 1]
            caller = self.memory[start : self.regs["FP"]]
            frame = self.memory[self.regs["FP"] : self.regs["SP"]]
            frame = frame[:20]
        print(f"      regs  ={self.regs}")
        print(f"      frame ={frame}")
        print(f"      caller={caller}")
        print(f"[{self.regs['PC']:4}] {insn}")

    def step(self) -> Optional["Execution"]:
        insn = self.insns[self.regs["PC"]]
        self.regs["PC"] += 1
        insn.execute(self.memory, self.regs, self.labels)
        return self

    def run(self):
        if self.verbose:
            print("Begin Execution")
            self.dump_state()
        o = self
        while o is not None:
            o = self.step()
            if self.verbose:
                self.dump_state()
        if self.verbose:
            print("End Execution")
