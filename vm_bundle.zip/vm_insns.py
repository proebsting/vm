from typing import List, Dict
from dataclasses import dataclass


def halt():
    raise Exception("Halt")


class Insn:
    def execute(
        self, memory: List[int], registers: Dict[str, int], labels: Dict[str, int]
    ) -> None:
        raise NotImplementedError(f"execute not implemented for {self.__class__}")

    def disasm(self, long: bool = False) -> str:
        raise NotImplementedError(f"disasm not implemented for {self.__class__}")


@dataclass
class Label(Insn):
    label: str
    comment: str = ""

    def execute(
        self, memory: List[int], registers: Dict[str, int], labels: Dict[str, int]
    ):
        pass

    def disasm(self, long: bool = False) -> str:
        op = "Label" if long else "lab"
        return f"{op} {self.label} {self.comment}"


@dataclass
class Jump(Insn):
    label: str
    comment: str = ""

    def execute(
        self, memory: List[int], registers: Dict[str, int], labels: Dict[str, int]
    ):
        registers["PC"] = labels[self.label]

    def disasm(self, long: bool = False) -> str:
        op = "Jump" if long else "j"
        return f"{op} {self.label} {self.comment}"


@dataclass
class JumpIfZero(Insn):
    v: str
    label: str
    comment: str = ""

    def execute(
        self, memory: List[int], registers: Dict[str, int], labels: Dict[str, int]
    ):
        if registers[self.v] == 0:
            registers["PC"] = labels[self.label]

    def disasm(self, long: bool = False) -> str:
        op = "JumpIfZero" if long else "jz"
        return f"{op} {self.v} {self.label} {self.comment}"


@dataclass
class JumpIfNotZero(Insn):
    v: str
    label: str
    comment: str = ""

    def execute(
        self, memory: List[int], registers: Dict[str, int], labels: Dict[str, int]
    ):
        if registers[self.v] != 0:
            registers["PC"] = labels[self.label]

    def disasm(self, long: bool = False) -> str:
        op = "JumpIfNotZero" if long else "jnz"
        return f"{op} {self.v} {self.label} {self.comment}"


@dataclass
class JumpIndirect(Insn):
    v: str
    comment: str = ""

    def execute(
        self, memory: List[int], registers: Dict[str, int], labels: Dict[str, int]
    ):
        registers["PC"] = registers[self.v]

    def disasm(self, long: bool = False) -> str:
        op = "JumpIndirect" if long else "ji"
        return f"{op} {self.v} {self.comment}"


@dataclass
class Immediate(Insn):
    dst: str
    value: int
    comment: str = ""

    def execute(
        self, memory: List[int], registers: Dict[str, int], labels: Dict[str, int]
    ):
        registers[self.dst] = self.value

    def disasm(self, long: bool = False) -> str:
        op = "Immediate" if long else "imm"
        return f"{op} {self.dst} {self.value} {self.comment}"


@dataclass
class LoadLabel(Insn):
    dst: str
    label: str
    comment: str = ""

    def execute(
        self, memory: List[int], registers: Dict[str, int], labels: Dict[str, int]
    ):
        registers[self.dst] = labels[self.label]

    def disasm(self, long: bool = False) -> str:
        op = "LoadLabel" if long else "llabel"
        return f"{op} {self.dst} {self.label} {self.comment}"


@dataclass
class Add(Insn):
    dst: str
    x: str
    y: str
    comment: str = ""

    def execute(
        self, memory: List[int], registers: Dict[str, int], labels: Dict[str, int]
    ):
        registers[self.dst] = registers[self.x] + registers[self.y]

    def disasm(self, long: bool = False) -> str:
        op = "Add" if long else "add"
        return f"{op} {self.dst} {self.x} {self.y} {self.comment}"


@dataclass
class AddImmediate(Insn):
    dst: str
    x: str
    value: int
    comment: str = ""

    def execute(
        self, memory: List[int], registers: Dict[str, int], labels: Dict[str, int]
    ):
        registers[self.dst] = registers[self.x] + self.value

    def disasm(self, long: bool = False) -> str:
        op = "AddImmediate" if long else "addi"
        return f"{op} {self.dst} {self.x} {self.value} {self.comment}"


@dataclass
class Sub(Insn):
    dst: str
    x: str
    y: str
    comment: str = ""

    def execute(
        self, memory: List[int], registers: Dict[str, int], labels: Dict[str, int]
    ):
        registers[self.dst] = registers[self.x] - registers[self.y]

    def disasm(self, long: bool = False) -> str:
        op = "Sub" if long else "sub"
        return f"{op} {self.dst} {self.x} {self.y} {self.comment}"


@dataclass
class Mul(Insn):
    dst: str
    x: str
    y: str
    comment: str = ""

    def execute(
        self, memory: List[int], registers: Dict[str, int], labels: Dict[str, int]
    ):
        registers[self.dst] = registers[self.x] * registers[self.y]

    def disasm(self, long: bool = False) -> str:
        op = "Mul" if long else "mul"
        return f"{op} {self.dst} {self.x} {self.y} {self.comment}"


@dataclass
class Div(Insn):
    dst: str
    x: str
    y: str
    comment: str = ""

    def execute(
        self, memory: List[int], registers: Dict[str, int], labels: Dict[str, int]
    ):
        registers[self.dst] = registers[self.x] // registers[self.y]

    def disasm(self, long: bool = False) -> str:
        op = "Div" if long else "div"
        return f"{op} {self.dst} {self.x} {self.y} {self.comment}"


@dataclass
class Negate(Insn):
    dst: str
    v: str
    comment: str = ""

    def execute(
        self, memory: List[int], registers: Dict[str, int], labels: Dict[str, int]
    ):
        registers[self.dst] = -registers[self.v]

    def disasm(self, long: bool = False) -> str:
        op = "Negate" if long else "neg"
        return f"{op} {self.dst} {self.v} {self.comment}"


@dataclass
class LessThan(Insn):
    dst: str
    x: str
    y: str
    comment: str = ""

    def execute(
        self, memory: List[int], registers: Dict[str, int], labels: Dict[str, int]
    ):
        registers[self.dst] = registers[self.x] < registers[self.y]

    def disasm(self, long: bool = False) -> str:
        op = "LessThan" if long else "lt"
        return f"{op} {self.dst} {self.x} {self.y} {self.comment}"


@dataclass
class GreaterThan(Insn):
    dst: str
    x: str
    y: str
    comment: str = ""

    def execute(
        self, memory: List[int], registers: Dict[str, int], labels: Dict[str, int]
    ):
        registers[self.dst] = registers[self.x] > registers[self.y]

    def disasm(self, long: bool = False) -> str:
        op = "GreaterThan" if long else "gt"
        return f"{op} {self.dst} {self.x} {self.y} {self.comment}"


@dataclass
class LessThanEqual(Insn):
    dst: str
    x: str
    y: str
    comment: str = ""

    def execute(
        self, memory: List[int], registers: Dict[str, int], labels: Dict[str, int]
    ):
        registers[self.dst] = registers[self.x] <= registers[self.y]

    def disasm(self, long: bool = False) -> str:
        op = "LessThanEqual" if long else "leq"
        return f"{op} {self.dst} {self.x} {self.y} {self.comment}"


@dataclass
class GreaterThanEqual(Insn):
    dst: str
    x: str
    y: str
    comment: str = ""

    def execute(
        self, memory: List[int], registers: Dict[str, int], labels: Dict[str, int]
    ):
        registers[self.dst] = registers[self.x] >= registers[self.y]

    def disasm(self, long: bool = False) -> str:
        op = "GreaterThanEqual" if long else "geq"
        return f"{op} {self.dst} {self.x} {self.y} {self.comment}"


@dataclass
class Equal(Insn):
    dst: str
    x: str
    y: str
    comment: str = ""

    def execute(
        self, memory: List[int], registers: Dict[str, int], labels: Dict[str, int]
    ):
        registers[self.dst] = registers[self.x] == registers[self.y]

    def disasm(self, long: bool = False) -> str:
        op = "Equal" if long else "eq"
        return f"{op} {self.dst} {self.x} {self.y} {self.comment}"


@dataclass
class NotEqual(Insn):
    dst: str
    x: str
    y: str
    comment: str = ""

    def execute(
        self, memory: List[int], registers: Dict[str, int], labels: Dict[str, int]
    ):
        registers[self.dst] = registers[self.x] != registers[self.y]

    def disasm(self, long: bool = False) -> str:
        op = "NotEqual" if long else "neq"
        return f"{op} {self.dst} {self.x} {self.y} {self.comment}"


@dataclass
class Not(Insn):
    dst: str
    v: str
    comment: str = ""

    def execute(
        self, memory: List[int], registers: Dict[str, int], labels: Dict[str, int]
    ):
        registers[self.dst] = not registers[self.v]

    def disasm(self, long: bool = False) -> str:
        op = "Not" if long else "not"
        return f"{op} {self.dst} {self.v} {self.comment}"


@dataclass
class Load(Insn):
    dst: str
    address: str
    comment: str = ""

    def execute(
        self, memory: List[int], registers: Dict[str, int], labels: Dict[str, int]
    ):
        registers[self.dst] = memory[registers[self.address]]

    def disasm(self, long: bool = False) -> str:
        op = "Load" if long else "ld"
        return f"{op} {self.dst} {self.address} {self.comment}"


@dataclass
class Store(Insn):
    address: str
    v: str
    comment: str = ""

    def execute(
        self, memory: List[int], registers: Dict[str, int], labels: Dict[str, int]
    ):
        memory[registers[self.address]] = registers[self.v]

    def disasm(self, long: bool = False) -> str:
        op = "Store" if long else "st"
        return f"{op} {self.address} {self.v} {self.comment}"


@dataclass
class Print(Insn):
    v: str
    comment: str = ""

    def execute(
        self, memory: List[int], registers: Dict[str, int], labels: Dict[str, int]
    ):
        print(registers[self.v])

    def disasm(self, long: bool = False) -> str:
        op = "Print" if long else "print"
        return f"{op} {self.v} {self.comment}"


@dataclass
class CallIndirect(Insn):
    v: str
    comment: str = ""

    def execute(
        self, memory: List[int], registers: Dict[str, int], labels: Dict[str, int]
    ):
        registers["RA"] = registers["PC"]
        registers["PC"] = registers[self.v]

    def disasm(self, long: bool = False) -> str:
        op = "CallIndirect" if long else "calli"
        return f"{op} {self.v} {self.comment}"


@dataclass
class Call(Insn):
    label: str
    comment: str = ""

    def execute(
        self, memory: List[int], registers: Dict[str, int], labels: Dict[str, int]
    ):
        registers["RA"] = registers["PC"]
        registers["PC"] = labels[self.label]

    def disasm(self, long: bool = False) -> str:
        op = "Call" if long else "call"
        return f"{op} {self.label} {self.comment}"


@dataclass
class Halt(Insn):
    comment: str = ""

    def execute(
        self, memory: List[int], registers: Dict[str, int], labels: Dict[str, int]
    ):
        halt()

    def disasm(self, long: bool = False) -> str:
        op = "Halt" if long else "halt"
        return f"{op} {self.comment}"


reserved = [
    "Label",
    "lab",
    "Jump",
    "j",
    "JumpIfZero",
    "jz",
    "JumpIfNotZero",
    "jnz",
    "JumpIndirect",
    "ji",
    "Immediate",
    "imm",
    "LoadLabel",
    "llabel",
    "Add",
    "add",
    "AddImmediate",
    "addi",
    "Sub",
    "sub",
    "Mul",
    "mul",
    "Div",
    "div",
    "Negate",
    "neg",
    "LessThan",
    "lt",
    "GreaterThan",
    "gt",
    "LessThanEqual",
    "leq",
    "GreaterThanEqual",
    "geq",
    "Equal",
    "eq",
    "NotEqual",
    "neq",
    "Not",
    "not",
    "Load",
    "ld",
    "Store",
    "st",
    "Print",
    "print",
    "CallIndirect",
    "calli",
    "Call",
    "call",
    "Halt",
    "halt",
]
